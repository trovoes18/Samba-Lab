#!/usr/bin/env python
# Copyright (C) 2023 Fortra. All rights reserved.
#
# This software is provided under under a slightly modified version
# of the Apache Software License. See the accompanying LICENSE file
# for more information.
#
